import React from 'react';
import ProductChatList from './ProductChatList';

// You can import supported modules from npm

export default function App() {
  return <ProductChatList />;
}