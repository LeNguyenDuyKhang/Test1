import React from 'react';
import ProductListingPage from './ProductListingPage'

export default function App() {
  return <ProductListingPage />;
}